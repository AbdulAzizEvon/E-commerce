<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\ResetPasswordController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CartController;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/authenticate', [UserController::class, 'authenticate'])->name('authenticate');
Route::post('/store', [UserController::class,'store'])->name('store');
Route::get('/logout', [UserController::class,'logout'])->name('logout');


Route::middleware(['Preventbackhistory'])->group(function () {
    Route::get('/login',[UserController::class, 'login'])->name('login');
    Route::get('/register', [UserController::class,'register'])->name('register');
    Route::get('/home', [UserController::class,'home'])->name('home')->middleware('UserAuthMiddleware');
    Route::get('/dashboard', [UserController::class,'dashboard'])->name('dashboard') ->middleware('AdminAuthMiddleware');

});


Route::get('forgot-password', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');


Route::middleware('AdminAuthMiddleware')->group(function () {
    // Show the profile edit form
    Route::get('profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');

    // Handle the profile update
    Route::put('profile/update', [ProfileController::class, 'update'])->name('profile.update');
    });




// cart route

Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/{id}/add', [CartController::class, 'addToCart'])->name('cart.add');
Route::post('/cart/{id}/remove', [CartController::class, 'removeFromCart'])->name('cart.remove');
Route::post('/cart/{id}/update', [CartController::class, 'updateQuantity'])->name('cart.update');
