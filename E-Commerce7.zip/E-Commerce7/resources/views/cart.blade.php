<!-- resources/views/cart.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <div class="cart-container">
        <h1>Your Shopping Cart</h1>

        <div class="cart-items">
            @foreach($cartItems as $item)
                <div class="cart-item" data-id="{{ $item->id }}">
                    <img src="{{ asset('images/' . $item->image) }}" alt="{{ $item->name }}" class="cart-item-image">
                    <div class="cart-item-details">
                        <h3>{{ $item->name }}</h3>
                        <p>{{ $item->description }}</p>
                        <div class="quantity">
                            <button class="decrease-quantity">-</button>
                            <input type="number" value="{{ $item->quantity }}" class="item-quantity" min="1">
                            <button class="increase-quantity">+</button>
                        </div>
                        <p class="item-price">${{ number_format($item->price, 2) }}</p>
                    </div>
                    <button class="remove-item">Remove</button>
                </div>
            @endforeach
        </div>

        <div class="cart-summary">
            <p>Total: $<span id="total-price">{{ number_format($totalPrice, 2) }}</span></p>
            <button class="checkout-btn">Proceed to Checkout</button>
        </div>
    </div>

    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
