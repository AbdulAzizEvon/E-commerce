<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
</head>
<body>
    <form method="POST" action="{{ route('password.email') }}">
        @csrf
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Send Reset Link</button>

        @if(session('status'))
            <div>{{ session('status') }}</div>
        @endif

        @error('email')
            <div>{{ $message }}</div>
        @enderror
    </form>
</body>
</html>
