<?php

namespace App\Http\Controllers;

use view;
// use session;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function register(){
        if(Session::get('email')){
            $email = Session::get('email');
            $user = User::where('email', $email)->first();
            if($user && $user->role=='admin'){
                return redirect()->route('dashboard');
            }
            else{
                return redirect()->route('home');
            }
        }
        return view('register');
    }
    public function home(){
        // if(Session::get('email')){
        //     $email = Session::get('email');
        //     $user = User::where('email', $email)->first();
        //     if($user && $user->role=='admin'){
        //         return redirect()->route('dashboard');
        //     }
        //     else{
        //         return redirect()->route('welcome');
        //     }
        // }
        return view('home');
    }
    public function login()
    {
        if(Session::get('email')){
            $email = Session::get('email');
            $user = User::where('email', $email)->first();
            if($user && $user->role=='admin'){
                return redirect()->route('dashboard');
            }
            else{
                return redirect()->route('home');
            }
            if ($request->remember) {
                $user->generateRememberToken(); // Generate and store remember token in the database

                // Store the token in the cookie for the user
                Cookie::queue('remember_token', $user->remember_token, 60 * 24 * 30); // 30 days
            }
        }
        return view('login');
    }
    public function dashboard()
    {
        return view('dashboard');
    }
    public function store(Request $request) {

        $request->validate([
            'email' => 'required|confirmed|email',
            'email_confirmation' => 'required_with:email|same:email|email',
            'password' => 'required|confirmed|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]+$/',
            'password_confirmation' => 'required_with:password|same:password|min:8',
        ]);
            // $user=User::create($request->all());
            User::create([
                'First_Name' => $request->First_Name,
                'Last_Name' => $request->Last_Name,
                'email' => $request->email,
                'email_confirmation' => $request->email_confirmation,
                'password' => Hash::make($request->password),
                'password_confirmation' => Hash::make($request->password_confirmation),
                'Gender' => $request->Gender,
                'birthday_day' => $request->birthday_day,
                'birthday_month' => $request->birthday_month,
                'birthday_year' => $request->birthday_year,
                'UserName' => $request->UserName
            ]);

        if (Auth::attempt(['email' => $request->email,'password' =>$request->password])){
            // dd(Auth::check());
                // return redirect()->route('dashboard') ->withSuccess('You have successfully registered & logged in!');
                return redirect()->intended('emailvarification');
            }
            else {
                return redirect()->intended('register');

                }

        }


public function authenticate(Request $request):RedirectResponse
{
$user =User::where('email',$request->email)->first();
        if($user){
            if(password_verify($request->password,$user->password)){
                $userId =$user->User_ID;
                $email=$user->email;
                Session::put('userId',$userId);
                Session::put('email',$email);
                if(!empty($request->remember))
                {
                    setcookie('email',$request->email,time()+3600);
                    setcookie('password',$request->password,time()+3600);
                 }
                 else{
                     setcookie('email','');
                     setcookie('password','');

                 }
                if($user->role=='admin'){
                    return redirect()->route('dashboard');
                }
                else{
                    return redirect()->route('home');
                }


            }
            else{
                echo "password invalid";
            }
        }
        else{
            echo "email  invalid";
        }
        return redirect()->route('home');
    }

    public function logout(Request $request): RedirectResponse
    {
        Session::flush();
        // Invalidate the remember token and remove the cookie
        // $request->session()->invalidate();
        // $request->session()->regenerateToken();

        // // Remove the remember me cookie
        // Cookie::queue(Cookie::forget('remember_token'));

        return redirect()->route('home');
    }
}


