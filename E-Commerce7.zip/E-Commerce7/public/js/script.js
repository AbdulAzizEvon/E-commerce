const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');

allSideMenu.forEach(item=> {
	const li = item.parentElement;

	item.addEventListener('click', function () {
		allSideMenu.forEach(i=> {
			i.parentElement.classList.remove('active');
		})
		li.classList.add('active');
	})
});




// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');

menuBar.addEventListener('click', function () {
	sidebar.classList.toggle('hide');
})

const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');

searchButton.addEventListener('click', function (e) {
	if(window.innerWidth < 576) {
		e.preventDefault();
		searchForm.classList.toggle('show');
		if(searchForm.classList.contains('show')) {
			searchButtonIcon.classList.replace('bx-search', 'bx-x');
		} else {
			searchButtonIcon.classList.replace('bx-x', 'bx-search');
		}
	}
})

if(window.innerWidth < 768) {
	sidebar.classList.add('hide');
} else if(window.innerWidth > 576) {
	searchButtonIcon.classList.replace('bx-x', 'bx-search');
	searchForm.classList.remove('show');
}


window.addEventListener('resize', function () {
	if(this.innerWidth > 576) {
		searchButtonIcon.classList.replace('bx-x', 'bx-search');
		searchForm.classList.remove('show');
	}
})



const switchMode = document.getElementById('switch-mode');

switchMode.addEventListener('change', function () {
	if(this.checked) {
		document.body.classList.add('dark');
	} else {
		document.body.classList.remove('dark');
	}
})

// const links = document.querySelectorAll("li>a>.text");
// const adminPanels= document.querySelectorAll(".admin-panel");
// // console.log(links);
// [...links].map((link,index) =>{
    // link.addEventListener("click", () => onlinkclick(link,index),false)
    // });

// const onlinkclick = (link,currentIndex) => {
// 	// console.log(selectedItem);
//     adminPanels.forEach(adminPanel=>{
// 		adminPanel.classList.remove("active");
//     });

// };

// const selectedItem =link.getAttribute("Name");
// const currentAdmin=[...adminPanels].find((adminPanel)=>
// adminPanel.classList.contains(selectedItem)
// );
// console.log(currentAdmin);
// selectedItem.addEventListener('click',()=> {
// 	currentAdmin.classList.Add("Active");
// })

// const currentAdmin =

// const links = document.querySelectorAll("li>a>.text");
// const adminPanels= document.querySelectorAll(".admin-panel");
// public/js/script.js

document.addEventListener('DOMContentLoaded', function () {
    const cartItems = document.querySelectorAll('.cart-item');
    const totalPriceElement = document.getElementById('total-price');

    cartItems.forEach(item => {
        const increaseButton = item.querySelector('.increase-quantity');
        const decreaseButton = item.querySelector('.decrease-quantity');
        const removeButton = item.querySelector('.remove-item');
        const quantityInput = item.querySelector('.item-quantity');

        increaseButton.addEventListener('click', () => updateQuantity(item, 1));
        decreaseButton.addEventListener('click', () => updateQuantity(item, -1));
        removeButton.addEventListener('click', () => removeItem(item));

        function updateQuantity(item, change) {
            let quantity = parseInt(quantityInput.value);
            quantity = Math.max(1, quantity + change);
            quantityInput.value = quantity;
            updateCartTotal();
        }

        function removeItem(item) {
            item.remove();
            updateCartTotal();
        }
    });

    function updateCartTotal() {
        let total = 0;

        document.querySelectorAll('.cart-item').forEach(item => {
            const price = parseFloat(item.querySelector('.item-price').innerText.replace('$', ''));
            const quantity = parseInt(item.querySelector('.item-quantity').value);
            total += price * quantity;
        });

        totalPriceElement.innerText = total.toFixed(2);
    }
});
